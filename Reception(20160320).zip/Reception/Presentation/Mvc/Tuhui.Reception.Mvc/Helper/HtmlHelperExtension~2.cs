﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Data;
using Tuhui.Common45.Utility;
using Tuhui.Reception.Model;
using System.Xml;

namespace Tuhui.Reception.Mvc
{
    public static partial class ReceptionHtmlHelperExtension
    {
        
    }
}
