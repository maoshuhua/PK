﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using Tuhui.Reception.Service;

namespace Tuhui.Reception.Mvc
{
    public static partial class ReceptionHtmlHelperExtension
    {
        
    }
}
