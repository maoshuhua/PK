﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tuhui.Common45.Exception
{
    public class UserException : System.Exception
    {
        public UserException()
            : base()
        {

        }

        public UserException(string message, params object[] parameter)
            : base()
        {

        }
    }
}
