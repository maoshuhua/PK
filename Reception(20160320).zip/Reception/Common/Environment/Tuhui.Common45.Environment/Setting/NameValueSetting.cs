﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tuhui.Common45.Environment
{
    /// <summary>
    /// 键值对配置
    /// </summary>
    public class NameValueSetting
    {
        public Dictionary<string, string> NameValues { get; set; }
    }
}
