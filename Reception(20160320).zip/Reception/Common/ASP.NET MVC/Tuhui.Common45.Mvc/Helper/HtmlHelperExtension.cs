﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace Tuhui.Common45.Mvc
{
    /// <summary>
    /// HtmlHelper类方法扩展
    /// </summary>
    public static partial class HtmlHelperExtension
    {
    }
}
