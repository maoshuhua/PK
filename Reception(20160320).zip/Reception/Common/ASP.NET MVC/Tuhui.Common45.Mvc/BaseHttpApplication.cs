﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tuhui.Common45.Mvc
{
    /// <summary>
    /// global.cs中HttpApplication基类
    /// </summary>
    public abstract class BaseHttpApplication : System.Web.HttpApplication
    {
    }
}
